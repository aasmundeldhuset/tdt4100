package inheritance;

public interface Employee {
	void work();
}
