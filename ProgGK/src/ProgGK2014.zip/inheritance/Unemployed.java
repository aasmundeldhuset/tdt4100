package inheritance;

public class Unemployed extends Person {
	public Unemployed(String name, int age) {
		super(name, age);
	}
}
